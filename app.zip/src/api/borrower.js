import axios from './axiosConfig';

export const getBorrowers = async () => {
  const response = await axios.get('/borrowers');
  return response.data.results || [];
};

export const createBorrower = async (data) => {
  const response = await axios.post('/borrowers', data);
  return response.data;
};
