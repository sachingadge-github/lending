import React, { useEffect, useState } from 'react';
import { Grid, Typography } from '@mui/material';
import MainCard from '../../components/MainCard';
import { getBorrowers } from '../../api/borrower';
import { MaterialReactTable } from 'material-react-table';


const BorrowerList = () => {
  const [borrowers, setBorrowers] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchBorrowers = async () => {
      try {
        const data = await getBorrowers();
        setBorrowers(data);
      } catch (error) {
        console.error('Failed to fetch borrowers', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchBorrowers();
  }, []);

  const columns = [
    { accessorKey: 'name', header: 'Name' },
    { accessorKey: 'email', header: 'Email' },
    { accessorKey: 'phone', header: 'Phone' },
    { accessorKey: 'kycStatus', header: 'KYC Status' }
  ];

  return (
    <Grid container spacing={3}>
      <Grid item xs={12}>
        <Typography variant="h5">Borrowers</Typography>
        <MainCard sx={{ mt: 2 }} content={false}>
          <MaterialReactTable
            columns={columns}
            data={borrowers}
            state={{ isLoading }}
            enableColumnFilters
            enableSorting
            enablePagination
          />
        </MainCard>
      </Grid>
    </Grid>
  );
};

export default BorrowerList;
